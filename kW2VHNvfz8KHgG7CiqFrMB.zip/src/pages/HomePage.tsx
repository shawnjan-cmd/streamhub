import { Play, Lock, MessageCircle, Smartphone, Zap, Loader2 } from 'lucide-react';
import PartyCard from '../components/features/PartyCard';
import heroImage from '../assets/hero-watchparty.jpg';
import { useParties } from '@/hooks/useParties';
import { useAuth } from '@/hooks/useAuth';

interface HomePageProps {
  onJoinParty: (partyId: string) => void;
  onNavigate: (page: 'discover' | 'create') => void;
}

export default function HomePage({ onJoinParty, onNavigate }: HomePageProps) {
  const { parties, loading } = useParties();
  const { currentUser } = useAuth();
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="Friends watching together"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/90 to-background" />
        </div>
        
        <div className="relative z-10 container-custom py-24 sm:py-32">
          <div className="text-center max-w-4xl mx-auto space-y-8 animate-fade-in">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
              Watch Together,{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary-light">
                Stay Connected
              </span>
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto">
              Create private watch parties with friends. Real-time sync. Perfect audio. Zero hassle.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => onNavigate('create')}
                className="px-8 py-4 bg-gradient-to-r from-primary to-primary-dark text-white rounded-lg font-semibold text-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5" />
                Start Watching Now
              </button>
              <button
                onClick={() => onNavigate('discover')}
                className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-lg font-semibold text-lg hover:bg-white/20 transition-colors"
              >
                Browse Parties
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container-custom py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard
            icon={<Zap className="w-10 h-10" />}
            title="Perfect Sync"
            description="<200ms latency"
          />
          <FeatureCard
            icon={<Lock className="w-10 h-10" />}
            title="Private Rooms"
            description="Secure join codes"
          />
          <FeatureCard
            icon={<MessageCircle className="w-10 h-10" />}
            title="Real-Time Chat"
            description="Text, voice & video"
          />
          <FeatureCard
            icon={<Smartphone className="w-10 h-10" />}
            title="All Devices"
            description="Web, iOS, Android"
          />
        </div>
      </section>

      {/* Trending Parties */}
      <section className="container-custom py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold">Trending Now</h2>
          <button
            onClick={() => onNavigate('discover')}
            className="text-primary hover:text-primary-light transition-colors font-medium"
          >
            View All →
          </button>
        </div>
        
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : parties.length === 0 ? (
          <div className="text-center py-20 bg-surface border border-border rounded-xl">
            <div className="text-6xl mb-4">🎬</div>
            <h3 className="text-xl font-semibold mb-2">No active parties yet</h3>
            <p className="text-gray-400 mb-6">Be the first to create a watch party!</p>
            <button
              onClick={() => onNavigate('create')}
              className="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary-dark transition-colors"
            >
              Create Your First Party
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {parties.slice(0, 8).map((party) => (
              <PartyCard
                key={party.id}
                party={{
                  id: party.id,
                  title: party.name,
                  host: 'Host',
                  participants: 0,
                  maxCapacity: 12,
                  rating: 4.8,
                  genre: 'general',
                  poster: '🎬',
                }}
                onJoin={() => onJoinParty(party.id)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-surface border border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors">
      <div className="text-primary mb-4 flex justify-center">{icon}</div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import { Send, Mic, Video, MinusCircle, Loader2 } from 'lucide-react';
import { usePartyMembers } from '@/hooks/useParties';
import { supabase } from '@/lib/supabase';

interface WatchPageProps {
  partyId: string;
}

interface ChatMessage {
  id: string;
  user: string;
  message: string;
  timestamp: Date;
  avatar: string;
}

export default function WatchPage({ partyId }: WatchPageProps) {
  const [party, setParty] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { members } = usePartyMembers(partyId);

  useEffect(() => {
    fetchParty();
  }, [partyId]);

  const fetchParty = async () => {
    try {
      const { data, error } = await supabase
        .from('parties')
        .select('*')
        .eq('id', partyId)
        .single();

      if (error) throw error;
      setParty(data);
    } catch (error) {
      console.error('Error fetching party:', error);
    } finally {
      setLoading(false);
    }
  };
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', user: 'Sarah', message: 'This is awesome!', timestamp: new Date(), avatar: '👩' },
    { id: '2', user: 'John', message: 'Love this movie!', timestamp: new Date(), avatar: '👨' },
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [chatMinimized, setChatMinimized] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      setChatMessages([
        ...chatMessages,
        {
          id: Date.now().toString(),
          user: 'You',
          message: newMessage,
          timestamp: new Date(),
          avatar: '👤',
        },
      ]);
      setNewMessage('');
    }
  };



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!party) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-400">Party not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Section */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-black rounded-xl overflow-hidden aspect-video">
              <video
                className="w-full h-full"
                controls
                autoPlay
                poster="https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&h=450&fit=crop"
              >
                <source
                  src={party.video_url}
                  type="video/mp4"
                />
                Your browser does not support the video tag.
              </video>
            </div>
            
            <div className="bg-surface border border-border rounded-xl p-6">
              <h2 className="text-2xl font-bold mb-2">{party.name}</h2>
              <p className="text-gray-400 mb-4">
                {party.video_title} • {members.length} watching
              </p>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Party Code:</span>
                  <code className="px-3 py-1 bg-background border border-border rounded text-primary font-mono text-sm">
                    {party.party_code}
                  </code>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(party.party_code);
                  }}
                  className="text-xs text-gray-400 hover:text-primary transition-colors"
                >
                  Copy
                </button>
              </div>
            </div>
          </div>

          {/* Chat & Controls Section */}
          <div className="space-y-4">
            {/* Chat */}
            <div className="bg-surface border border-border rounded-xl overflow-hidden">
              <div className="p-4 border-b border-border flex items-center justify-between">
                <h3 className="font-semibold">Party Chat</h3>
                <button
                  onClick={() => setChatMinimized(!chatMinimized)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <MinusCircle className="w-5 h-5" />
                </button>
              </div>
              
              {!chatMinimized && (
                <>
                  <div className="h-64 overflow-y-auto p-4 space-y-3">
                    {chatMessages.map((msg) => (
                      <div key={msg.id} className="flex gap-3">
                        <div className="text-2xl">{msg.avatar}</div>
                        <div className="flex-1">
                          <div className="flex items-baseline gap-2">
                            <span className="font-medium text-sm">{msg.user}</span>
                            <span className="text-xs text-gray-500">
                              {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-sm text-gray-300 mt-1">{msg.message}</p>
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                  
                  <div className="p-4 border-t border-border">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Say something..."
                        className="flex-1 px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-white"
                      />
                      <button
                        onClick={handleSendMessage}
                        className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Voice/Video Controls */}
            <div className="bg-surface border border-border rounded-xl p-4">
              <div className="flex gap-2">
                <button
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={`flex-1 px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 ${
                    voiceEnabled
                      ? 'bg-primary text-white'
                      : 'bg-background text-gray-400 hover:text-white'
                  }`}
                >
                  <Mic className="w-5 h-5" />
                  Voice
                </button>
                <button
                  onClick={() => setVideoEnabled(!videoEnabled)}
                  className={`flex-1 px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 ${
                    videoEnabled
                      ? 'bg-primary text-white'
                      : 'bg-background text-gray-400 hover:text-white'
                  }`}
                >
                  <Video className="w-5 h-5" />
                  Video
                </button>
              </div>
            </div>

            {/* Participants */}
            <div className="bg-surface border border-border rounded-xl p-4">
              <h3 className="font-semibold mb-4">Participants ({members.length})</h3>
              <div className="space-y-2">
                {members.map((member) => (
                  <div key={member.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-background transition-colors">
                    <div className="text-2xl">{member.avatar}</div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{member.username}</p>
                      <p className="text-xs text-gray-500">{member.status}</p>
                    </div>
                    <div className="w-2 h-2 bg-success rounded-full" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

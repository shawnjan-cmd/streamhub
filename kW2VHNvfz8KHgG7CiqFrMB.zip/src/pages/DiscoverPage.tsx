import { useState, useMemo } from 'react';
import { Search, Loader2 } from 'lucide-react';
import PartyCard from '../components/features/PartyCard';
import { useParties } from '@/hooks/useParties';
import type { Party } from '@/lib/supabase';

interface DiscoverPageProps {
  onJoinParty: (partyId: string) => void;
}

export default function DiscoverPage({ onJoinParty }: DiscoverPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { parties, loading } = useParties();

  const filteredParties = useMemo(() => {
    return parties.filter((party: Party) => {
      const matchesSearch = searchQuery
        ? party.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          party.video_title.toLowerCase().includes(searchQuery.toLowerCase())
        : true;

      return matchesSearch;
    });
  }, [parties, searchQuery]);

  return (
    <div className="min-h-screen py-8">
      <div className="container-custom">
        <h1 className="text-4xl font-bold mb-8">Discover Watch Parties</h1>

        {/* Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search parties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-surface border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-white"
            />
          </div>
        </div>

        {/* Results Count */}
        {!loading && (
          <p className="text-gray-400 mb-6">
            Found {filteredParties.length} {filteredParties.length === 1 ? 'party' : 'parties'}
          </p>
        )}

        {/* Party Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : filteredParties.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg">
              {searchQuery ? 'No parties found matching your search' : 'No active parties found'}
            </p>
            <p className="text-gray-500 text-sm mt-2">Be the first to create one!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredParties.map((party) => (
              <PartyCard
                key={party.id}
                party={{
                  id: party.id,
                  title: party.name,
                  host: 'Host',
                  participants: 0,
                  maxCapacity: 12,
                  rating: 4.8,
                  genre: 'general',
                  poster: '🎬',
                }}
                onJoin={() => onJoinParty(party.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Film, Loader2, Search } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useParties } from '@/hooks/useParties';

interface CreatePartyPageProps {
  onPartyCreated: (partyId: string) => void;
}

export default function CreatePartyPage({ onPartyCreated }: CreatePartyPageProps) {
  const { currentUser } = useAuth();
  const { createParty } = useParties();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    videoUrl: '',
    videoTitle: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (!formData.name || !formData.videoUrl || !formData.videoTitle) {
        throw new Error('Please fill in all fields');
      }

      const party = await createParty(formData.name, formData.videoUrl, formData.videoTitle);
      
      if (party) {
        onPartyCreated(party.id);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to create party');
    } finally {
      setLoading(false);
    }
  };

  const popularMovies = [
    { title: 'Big Buck Bunny', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
    { title: 'Elephant Dream', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
    { title: 'Sintel', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4' },
  ];

  const handleSelectMovie = (movie: typeof popularMovies[0]) => {
    setFormData({
      ...formData,
      videoUrl: movie.url,
      videoTitle: movie.title,
      name: formData.name || `${movie.title} Watch Party`,
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container-custom max-w-2xl">
        <div className="text-center mb-8 animate-fade-in">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-dark rounded-full flex items-center justify-center mx-auto mb-4">
            <Film className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold mb-2">Create a Watch Party</h1>
          <p className="text-gray-400">Set up your party and invite friends to watch together</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm animate-slide-up">
            {error}
          </div>
        )}

        <div className="bg-surface border border-border rounded-xl p-6 animate-slide-up">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Party Name */}
            <div>
              <label className="block text-sm font-medium mb-2">Party Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Movie Night with Friends"
                className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-white"
                required
              />
            </div>

            {/* Quick Select */}
            <div>
              <label className="block text-sm font-medium mb-2">Quick Select (Demo Videos)</label>
              <div className="grid grid-cols-1 gap-2">
                {popularMovies.map((movie) => (
                  <button
                    key={movie.title}
                    type="button"
                    onClick={() => handleSelectMovie(movie)}
                    className="px-4 py-3 bg-background border border-border rounded-lg text-left hover:border-primary hover:bg-background/80 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <Film className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-medium">{movie.title}</p>
                        <p className="text-xs text-gray-500">Sample video</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Video Title */}
            <div>
              <label className="block text-sm font-medium mb-2">Video Title</label>
              <input
                type="text"
                value={formData.videoTitle}
                onChange={(e) => setFormData({ ...formData, videoTitle: e.target.value })}
                placeholder="Inception"
                className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-white"
                required
              />
            </div>

            {/* Video URL */}
            <div>
              <label className="block text-sm font-medium mb-2">Video URL</label>
              <input
                type="url"
                value={formData.videoUrl}
                onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                placeholder="https://example.com/video.mp4"
                className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-white"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter a direct video URL (.mp4, .webm) or streaming URL
              </p>
            </div>

            {/* Party Info */}
            <div className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-2">
              <h3 className="font-semibold text-sm text-primary">Party Details</h3>
              <div className="text-sm text-gray-400 space-y-1">
                <p>• Host: {currentUser?.name || 'You'}</p>
                <p>• Max Capacity: 12 people</p>
                <p>• Privacy: Private (Join code required)</p>
                <p>• You'll receive a unique party code to share</p>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full px-4 py-4 bg-gradient-to-r from-primary to-primary-dark text-white rounded-lg font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-5 h-5 animate-spin" />}
              {loading ? 'Creating Party...' : 'Create Watch Party'}
            </button>
          </form>
        </div>

        {/* Tips */}
        <div className="mt-6 bg-primary/5 border border-primary/20 rounded-lg p-4">
          <h3 className="font-semibold text-sm text-primary mb-2">💡 Tips for a Great Party</h3>
          <ul className="text-sm text-gray-400 space-y-1">
            <li>• Use a stable internet connection for best sync</li>
            <li>• Share the party code with friends before starting</li>
            <li>• Everyone can use chat, but only host controls playback</li>
            <li>• Video quality adapts automatically to your connection</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

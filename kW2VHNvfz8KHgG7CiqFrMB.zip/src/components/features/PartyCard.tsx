import { Users, Star } from 'lucide-react';

interface Party {
  id: string;
  title: string;
  host: string;
  participants: number;
  maxCapacity: number;
  rating: number;
  genre: string;
  poster: string;
}

interface PartyCardProps {
  party: Party;
  onJoin: () => void;
}

export default function PartyCard({ party, onJoin }: PartyCardProps) {
  return (
    <div className="bg-surface border border-border rounded-xl overflow-hidden card-hover cursor-pointer group">
      <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary-dark/20 flex items-center justify-center text-6xl">
        {party.poster}
      </div>
      
      <div className="p-4 space-y-3">
        <h3 className="font-semibold text-lg line-clamp-1 group-hover:text-primary transition-colors">
          {party.title}
        </h3>
        
        <div className="flex items-center gap-4 text-sm text-gray-400">
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{party.participants}/{party.maxCapacity}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
            <span>{party.rating.toFixed(1)}</span>
          </div>
        </div>
        
        <p className="text-sm text-gray-500">Hosted by {party.host}</p>
        
        <div className="flex gap-2 pt-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onJoin();
            }}
            className="flex-1 px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-primary-dark transition-colors"
          >
            Join
          </button>
          <button
            onClick={(e) => e.stopPropagation()}
            className="px-4 py-2 bg-background text-gray-300 rounded-lg font-medium hover:bg-border transition-colors"
          >
            Details
          </button>
        </div>
      </div>
    </div>
  );
}

import { Film, Bell } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: 'home' | 'discover' | 'create' | 'watch') => void;
  currentUser: any;
  onAuthClick: () => void;
}

export default function Navbar({ currentPage, onNavigate, currentUser, onAuthClick }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-secondary border-b border-border">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <Film className="w-8 h-8 text-primary" />
            <span className="text-xl font-bold hidden sm:block">WatchParty</span>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className={`text-sm font-medium transition-colors ${
                currentPage === 'home' ? 'text-primary' : 'text-gray-400 hover:text-white'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onNavigate('discover')}
              className={`text-sm font-medium transition-colors ${
                currentPage === 'discover' ? 'text-primary' : 'text-gray-400 hover:text-white'
              }`}
            >
              Discover
            </button>
            <button
              onClick={() => onNavigate('create')}
              className={`text-sm font-medium transition-colors ${
                currentPage === 'create' ? 'text-primary' : 'text-gray-400 hover:text-white'
              }`}
            >
              Create
            </button>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <button className="relative text-gray-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-danger rounded-full text-[10px] flex items-center justify-center text-white">
                3
              </span>
            </button>
            <button
              onClick={onAuthClick}
              className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary-dark transition-colors"
            >
              {currentUser ? currentUser.name : 'Login'}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

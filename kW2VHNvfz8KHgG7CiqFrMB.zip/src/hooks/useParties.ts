import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import type { Party, PartyMember } from '@/lib/supabase';

export function useParties() {
  const [parties, setParties] = useState<Party[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchParties();

    // Subscribe to real-time changes
    const subscription = supabase
      .channel('parties_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'parties' }, () => {
        fetchParties();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchParties = async () => {
    try {
      const { data, error } = await supabase
        .from('parties')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setParties(data || []);
    } catch (error) {
      console.error('Error fetching parties:', error);
    } finally {
      setLoading(false);
    }
  };

  const createParty = async (name: string, videoUrl: string, videoTitle: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Generate unique party code
      const partyCode = 'WP-' + Math.random().toString(36).substring(2, 8).toUpperCase();

      const { data, error } = await supabase
        .from('parties')
        .insert({
          name,
          video_url: videoUrl,
          video_title: videoTitle,
          host_id: user.id,
          party_code: partyCode,
          is_active: true,
        })
        .select()
        .single();

      if (error) throw error;

      // Auto-join as host
      if (data) {
        await joinParty(data.id);
      }

      return data;
    } catch (error) {
      console.error('Error creating party:', error);
      throw error;
    }
  };

  const joinParty = async (partyId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const username = user.user_metadata?.name || user.email?.split('@')[0] || 'User';
      const avatar = user.user_metadata?.avatar || '👤';

      const { error } = await supabase
        .from('party_members')
        .insert({
          party_id: partyId,
          user_id: user.id,
          username,
          avatar,
          status: 'watching',
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error joining party:', error);
      throw error;
    }
  };

  const leaveParty = async (partyId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('party_members')
        .delete()
        .eq('party_id', partyId)
        .eq('user_id', user.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error leaving party:', error);
      throw error;
    }
  };

  return {
    parties,
    loading,
    createParty,
    joinParty,
    leaveParty,
    refreshParties: fetchParties,
  };
}

export function usePartyMembers(partyId: string | null) {
  const [members, setMembers] = useState<PartyMember[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!partyId) {
      setMembers([]);
      setLoading(false);
      return;
    }

    fetchMembers();

    // Subscribe to real-time member changes
    const subscription = supabase
      .channel(`party_members_${partyId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'party_members', filter: `party_id=eq.${partyId}` },
        () => {
          fetchMembers();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [partyId]);

  const fetchMembers = async () => {
    if (!partyId) return;

    try {
      const { data, error } = await supabase
        .from('party_members')
        .select('*')
        .eq('party_id', partyId)
        .order('joined_at', { ascending: true });

      if (error) throw error;
      setMembers(data || []);
    } catch (error) {
      console.error('Error fetching members:', error);
    } finally {
      setLoading(false);
    }
  };

  return { members, loading };
}

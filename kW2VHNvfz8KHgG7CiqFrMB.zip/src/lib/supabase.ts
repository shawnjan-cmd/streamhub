import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database Types
export interface Party {
  id: string;
  name: string;
  video_url: string;
  video_title: string;
  host_id: string;
  party_code: string;
  created_at: string;
  is_active: boolean;
}

export interface PartyMember {
  id: string;
  party_id: string;
  user_id: string;
  username: string;
  avatar: string;
  joined_at: string;
  status: string;
}

import { useState } from 'react';
import Navbar from './components/layout/Navbar';
import HomePage from './pages/HomePage';
import DiscoverPage from './pages/DiscoverPage';
import WatchPage from './pages/WatchPage';
import CreatePartyPage from './pages/CreatePartyPage';
import AuthModal from './components/features/AuthModal';
import { useAuth } from './hooks/useAuth';
import { Loader2 } from 'lucide-react';

type Page = 'home' | 'discover' | 'create' | 'watch';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedPartyId, setSelectedPartyId] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { currentUser, loading: authLoading, signOut } = useAuth();

  const handleNavigate = (page: Page) => {
    if (page === 'create' && !currentUser) {
      setShowAuthModal(true);
      return;
    }
    setCurrentPage(page);
  };

  const handleJoinParty = (partyId: string) => {
    if (!currentUser) {
      setShowAuthModal(true);
      return;
    }
    setSelectedPartyId(partyId);
    setCurrentPage('watch');
  };

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#111827] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#111827] text-gray-100">
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        currentUser={currentUser}
        onAuthClick={() => currentUser ? handleLogout() : setShowAuthModal(true)}
      />
      
      <main className="pt-16">
        {currentPage === 'home' && (
          <HomePage
            onJoinParty={handleJoinParty}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'discover' && (
          <DiscoverPage onJoinParty={handleJoinParty} />
        )}
        {currentPage === 'create' && (
          <CreatePartyPage onPartyCreated={handleJoinParty} />
        )}
        {currentPage === 'watch' && selectedPartyId && (
          <WatchPage partyId={selectedPartyId} />
        )}
      </main>

      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={handleAuthSuccess}
        />
      )}
    </div>
  );
}

export default App;
